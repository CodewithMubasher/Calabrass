import { useEffect, useRef, useState, type PointerEvent } from "react"
import { HugeiconsIcon } from "@hugeicons/react"
import { Download01Icon, Note01Icon } from "@hugeicons/core-free-icons"

import { cn } from "cn"
import { ArtifactCard } from "@/components/artifact-card"
import { ArtifactDetail } from "@/components/artifact-detail"
import { useIsMobile } from "@/hooks/use-mobile"
import { useArtifactFiles, useSelectedArtifactPath, setSelectedArtifactPath, watchArtifacts } from "@/lib/artifact-store"
import { setArtifactsOpen } from "@/lib/panel-store"
import { api, startDownload } from "@/lib/api"

/**
 * The Artifacts rail: a right-hand panel that *pushes* the page instead of
 * covering it, which is why it sits beside the routed column in `__root.tsx`
 * rather than inside a page.
 *
 * It stays mounted and animates its own width, so closing is as smooth as
 * opening. The outer element reserves the space — 360px of panel plus its right
 * gutter — while the panel inside keeps its full size and is revealed by that
 * width, so its contents never squash mid-transition. The same applies to the
 * detail's maximize: the rail grows to fill the row and the app column gives up
 * its width, rather than the panel lifting out and covering it.
 *
 * A phone has no width to give away, so there the rail changes form: it comes
 * in over the app from the right edge, dimming what is behind it, and is swiped
 * — in from the edge when it is shut, out to the right when it is open. Nothing
 * of this is desktop's: every rule it rests on is written for widths under the
 * same 768px the sidebar and `max-md:` already split on.
 *
 * What it lists is real: the files in the workspace this chat works in, read
 * from disk by the backend and pushed here whenever they change, so a file the
 * agent writes is in the list without a reload, and one it deletes leaves it.
 * The list is only followed while the rail is open — reopening draws the last
 * listing it had, and the connection corrects it immediately.
 *
 * Two views live in the one card: the list, and the file opened from it.
 * Dismissing either the rail or the detail returns to the list — and returns
 * the rail to its own width, since maximizing is part of reading a document.
 *
 * The header's download icon takes the whole workspace as one archive, since a
 * browser starts one download per click; each row and the detail have their own
 * for a single file.
 */
export function ArtifactsPanel({
  open,
  chatId,
}: {
  open: boolean
  chatId: string
}) {
  const files = useArtifactFiles(chatId)
  const selectedPath = useSelectedArtifactPath(chatId)
  const [maximized, setMaximized] = useState(false)
  const isMobile = useIsMobile()
  const sheetRef = useRef<HTMLElement>(null)

  const setSelectedPath = (path: string | null) => {
    setSelectedArtifactPath(chatId, path)
  }

  /**
   * How far the sheet has been dragged, in pixels to the right of open, or null
   * when it is not being held. The sheet is shut at its own width and open at
   * zero, so a rightward drag is what puts it away and the same number answers
   * both directions.
   */
  const [slideX, setSlideX] = useState<number | null>(null)
  const swipe = useRef({
    x: 0,
    y: 0,
    /** Where the drag started: 0 open, the sheet's width shut. */
    from: 0,
    width: 0,
    /** What the first real movement said this drag is. */
    axis: "" as "" | "x" | "y",
    startedAt: 0,
  })

  /**
   * A swipe on a phone. It begins on the edge strip when the rail is shut and on
   * the rail itself when it is open; either way the sheet follows the finger,
   * and the first movement decides what the drag is — sideways is the sheet's,
   * downward is the list's scroll, which is why a long list can still be
   * scrolled from the left.
   *
   * Desktop never starts one: the rail there is pushed by the layout, not
   * dragged, and a stray mouse drag must not put it away.
   */
  const startSwipe = (event: PointerEvent<HTMLElement>) => {
    if (!isMobile) return
    const width = sheetRef.current?.offsetWidth ?? 0
    if (width === 0) return

    swipe.current = {
      x: event.clientX,
      y: event.clientY,
      from: open ? 0 : width,
      width,
      axis: "",
      startedAt: performance.now(),
    }
    setSlideX(swipe.current.from)
    // No explicit capture: a touch pointer is implicitly captured by the
    // element it went down on, so the drag keeps arriving here — and taking the
    // pointer in hand would retarget the tap as well, which is what would stop
    // the buttons inside the sheet from working on a phone.
  }

  const moveSwipe = (event: PointerEvent<HTMLElement>) => {
    const gesture = swipe.current
    if (gesture.width === 0) return

    const dx = event.clientX - gesture.x
    const dy = event.clientY - gesture.y

    if (gesture.axis === "") {
      // A few pixels of slop first, so a tap stays a tap and a scroll starts
      // where the finger did.
      if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return
      if (Math.abs(dx) <= Math.abs(dy)) {
        // Not ours. Dropping out of the gesture leaves the list its scroll.
        gesture.axis = "y"
        gesture.width = 0
        setSlideX(null)
        return
      }
      gesture.axis = "x"
    }

    // Neither past the middle nor off the edge: the sheet tracks the finger
    // within the two states it has.
    setSlideX(Math.min(gesture.width, Math.max(0, gesture.from + dx)))
  }

  const endSwipe = () => {
    const gesture = swipe.current
    const { width, from, axis, startedAt } = gesture
    gesture.width = 0

    if (axis !== "x") {
      setSlideX(null)
      return
    }

    const settled = slideX ?? from
    // Towards shut is a positive drag; towards open, negative.
    const towards = settled - from
    const flick = performance.now() - startedAt < 250 && Math.abs(towards) > 24

    // A flick is a decision on its own. Otherwise the sheet has to have been
    // carried past the middle for the state to change.
    setArtifactsOpen(flick ? towards < 0 : settled < width / 2)
    setSlideX(null)
  }

  // A closed rail is a dismissed detail: reopening always lands on the list
  // rather than inside whatever was open — and un-maximized, so the rail can
  // never come back covering the app.
  //
  // This tracks `open` during render instead of in an effect, which is what
  // React asks for when state has to follow a prop. Clearing on the way *in*
  // rather than on the way out is deliberate: the detail then stays on screen
  // for the whole exit, instead of flipping to the list while it slides away.
  const [wasOpen, setWasOpen] = useState(open)
  if (wasOpen !== open) {
    setWasOpen(open)
    if (open) {
      setSelectedPath(null)
      setMaximized(false)
    }
  }

  // Follow the workspace for as long as the rail is on screen.
  useEffect(() => {
    if (!open) return
    return watchArtifacts(chatId)
  }, [open, chatId])

  function closeDetail() {
    setSelectedPath(null)
    setMaximized(false)
  }

  // Taken from the listing rather than held as a copy, so the open file is
  // always the freshest one — and a file that is deleted closes the detail by
  // itself, since it is no longer in the list to find.
  const selected =
    files.find((file) => file.path === selectedPath) ?? null

  return (
    <>
      {/* The app behind the sheet, dimmed on a phone only, and tappable: a
          backdrop is what a drawer is put away with when the swipe is not the
          way the user reaches for. */}
      <div
        aria-hidden="true"
        onClick={() => setArtifactsOpen(false)}
        className={cn(
          "hidden max-md:fixed max-md:inset-0 max-md:z-30 max-md:block max-md:bg-black/60 max-md:transition-opacity max-md:duration-300",
          open ? "max-md:opacity-100" : "max-md:pointer-events-none max-md:opacity-0"
        )}
      />

      {/* Where a swipe in begins: a finger's width of the screen's right edge,
          which is empty gutter on every screen the rail can be opened from. */}
      {!open ? (
        <div
          aria-hidden="true"
          onPointerDown={startSwipe}
          onPointerMove={moveSwipe}
          onPointerUp={endSwipe}
          onPointerCancel={endSwipe}
          className="hidden max-md:fixed max-md:inset-y-0 max-md:right-0 max-md:z-30 max-md:block max-md:w-4 max-md:touch-none"
        />
      ) : null}

      <aside
        ref={sheetRef}
        aria-label="Artifacts"
        aria-hidden={!open}
        inert={!open}
        onPointerDown={startSwipe}
        onPointerMove={moveSwipe}
        onPointerUp={endSwipe}
        onPointerCancel={endSwipe}
        style={
          slideX === null
            ? undefined
            : // `translate`, not `transform`: that is the property Tailwind
              // v4's translate utilities set, and with no transition the sheet
              // is under the finger rather than chasing after it.
              { translate: `${slideX}px`, transition: "none" }
        }
        className={cn(
          "flex h-full shrink-0 items-center overflow-hidden transition-[width] duration-300 ease-out",
          // A phone gives the rail no width to take, so it stops pushing and
          // comes in over the app instead, leaving a sliver of it showing so it
          // is plain the sheet slid over something.
          "max-md:fixed max-md:inset-y-0 max-md:right-0 max-md:z-40 max-md:w-[86%] max-md:max-w-[22rem] max-md:touch-pan-y max-md:transition-transform",
          open ? (maximized ? "w-full" : "w-[376px]") : "w-0 max-md:translate-x-full"
        )}
      >
        <div
          className={cn(
            "flex h-[calc(100%-2rem)] shrink-0 flex-col overflow-hidden rounded-2xl border border-white/15 bg-black/40 backdrop-blur-xl transition-[width] duration-300 ease-out",
            // 360px of panel beside a 16px gutter; maximized, it takes the row
            // and keeps that gutter on both sides.
            maximized ? "mx-4 w-[calc(100%-2rem)]" : "mr-4 w-[360px]",
            // A phone's sheet is the card itself, right up to the edge it slid
            // in from, with only the corners it came in on rounded.
            "max-md:mx-0 max-md:h-full max-md:w-full max-md:rounded-l-2xl max-md:rounded-r-none max-md:border-y-0 max-md:border-r-0"
          )}
        >
        {selected ? (
          <ArtifactDetail
            key={selected.path}
            chatId={chatId}
            file={selected}
            maximized={maximized}
            onToggleMaximize={() => setMaximized((value) => !value)}
            onClose={closeDetail}
          />
        ) : (
          <>
            <header className="flex h-11 shrink-0 items-center gap-2 px-3">
              <HugeiconsIcon
                icon={Note01Icon}
                strokeWidth={2}
                className="size-4 text-white/50"
              />
              <span className="text-sm font-medium text-white">Artifacts</span>
              <button
                type="button"
                aria-label="Download all"
                onClick={() => startDownload(api.artifactsArchiveUrl(chatId))}
                disabled={files.length === 0}
                className="ml-auto grid size-7 cursor-pointer place-items-center rounded-lg text-white/50 outline-none transition-colors hover:bg-white/10 hover:text-white focus-visible:ring-2 focus-visible:ring-white/20 disabled:cursor-default disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-white/50"
              >
                <HugeiconsIcon
                  icon={Download01Icon}
                  strokeWidth={2}
                  className="size-3.5"
                />
              </button>
            </header>

            <div className="scrollbar-thin min-h-0 flex-1 overflow-y-auto p-3">
              {files.length === 0 ? (
                <div className="flex h-full items-center justify-center px-6 text-center">
                  <p className="text-xs text-white/40">
                    No files in this workspace yet. Anything the agent writes
                    lands here.
                  </p>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {files.map((file) => (
                    <ArtifactCard
                      key={file.path}
                      file={file}
                      onSelect={() => setSelectedPath(file.path)}
                      onDownload={() =>
                        startDownload(api.artifactFileUrl(chatId, file.path))
                      }
                    />
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>
      </aside>
    </>
  )
}
